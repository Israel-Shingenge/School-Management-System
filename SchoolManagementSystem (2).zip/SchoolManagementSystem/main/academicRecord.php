<?php
session_start();

if (!isset($_SESSION['email'])) {
    echo "You must be logged in to view grades.";
    exit;
}

$email = $_SESSION['email'];

$host = 'localhost';
$dbname = 'management';
$username = 'root';
$password = '';
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT subject, grade, remarks, exam_name, created_at FROM grades WHERE email = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email); 
$stmt->execute();
$result = $stmt->get_result();
$grades = $result->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Academic Record</title>
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/student.css">
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/grades.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav>
    <ul>
        <li><a href="/SchoolManagementSystem/index.html">Home</a></li>
        <li><a href="/SchoolManagementSystem/main/dashboard.html">Dashboard</a></li>
        <li><a href="/SchoolManagementSystem/main/communication.html">Communication</a></li>
        <li><a href="/SchoolManagementSystem/main/examdashboard/examdashboard.html">Examination</a></li>
        <li><a href="/SchoolManagementSystem/main/teacherMan.html">Teacher</a></li>
        <li><a href="/SchoolManagementSystem/main/student.html">Student</a></li>
        <li><a href="/SchoolManagementSystem/main/fee.html">Fees</a></li>
        <li><a href="/SchoolManagementSystem/main/AboutUs.html">About us</a></li>
        <li><a href="/SchoolManagementSystem/backend/logout.php">Logout</a></li>
    </ul>
</nav>

<!-- Main Content -->
<div class="container">
    <h1>Academic Record</h1>
    <table class="grades-table">
        <thead>
            <tr>
                <th>Subject</th>
                <th>Grade</th>
                <th>Remarks</th>
                <th>Exam Name</th>
                <th>Exam Date</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($grades as $grade): ?>
                <tr>
                    <td><?php echo htmlspecialchars($grade['subject']); ?></td>
                    <td><?php echo htmlspecialchars($grade['grade']); ?></td>
                    <td><?php echo htmlspecialchars($grade['remarks']); ?></td>
                    <td><?php echo htmlspecialchars($grade['exam_name']); ?></td>
                    <td><?php echo htmlspecialchars($grade['created_at']); ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Styling -->
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    nav {
        background-color: navy;
        color: white;
        padding: 15px ;
    }

    nav ul {
        display: flex;
        justify-content: center;
        list-style: none;
        margin: 0;
        padding: 0;
    }

    nav ul li {
        margin: 0 15px;
    }

    nav ul li a {
        color: white;
        text-decoration: none;
        padding: 10px;
    }

    nav ul li a:hover {
        background-color: #007bff;
        border-radius: 5px;
    }

    .container {
        width: 80%;
        margin: 20px auto;
        background-color: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
    }

    .grades-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .grades-table th, .grades-table td {
        padding: 12px;
        text-align: left;
        border: 1px solid #ddd;
    }

    .grades-table th {
        background-color: #007bff;
        color: white;
    }

    .grades-table td {
        background-color: #f9f9f9;
    }

    .grades-table tr:hover {
        background-color: #f1f1f1;
    }

    .grades-table td {
        color: #333;
    }
</style>

</body>
</html>

<?php
$conn->close();
?>
