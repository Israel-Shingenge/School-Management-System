<?php
session_start();

$email = $_SESSION['email']; 

$host = 'localhost';
$dbname = 'management'; 
$username = 'root';
$password = '';
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$query = "SELECT attendance_date, subject, status FROM attendance WHERE email = ? ORDER BY attendance_date DESC";
$stmt = $conn->prepare($query);
$stmt->bind_param("s", $email); 
$stmt->execute();
$result = $stmt->get_result();
$attendance_records = $result->fetch_all(MYSQLI_ASSOC);

?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Attendance Records</title>
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/student.css">
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/attendance.css">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">
</head>
<body>

<!-- Navbar -->
<nav>
    <ul>
        <li><a href="/SchoolManagementSystem/index.html">Home</a></li>
        <li><a href="/SchoolManagementSystem/main/dashboard.html">Dashboard</a></li>
        <li><a href="/SchoolManagementSystem/main/communication.html">Communication</a></li>
        <li><a href="/SchoolManagementSystem/main/examdashboard/examdashboard.html">Examination</a></li>
        <li><a href="/SchoolManagementSystem/main/teacherMan.html">Teacher</a></li>
        <li><a href="/SchoolManagementSystem/main/student.html">Student</a></li>
        <li><a href="/SchoolManagementSystem/main/fee.html">Fees</a></li>
        <li><a href="/SchoolManagementSystem/main/AboutUs.html">About us</a></li>
        <li><a href="/SchoolManagementSystem/backend/logout.php">Logout</a></li>
    </ul>
</nav>

<!-- Main Content -->
<div class="container">
    <h1>Attendance Records</h1>
    <table class="attendance-table">
        <thead>
            <tr>
                <th>Date</th>
                <th>Subject</th>
                <th>Status</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($attendance_records as $record): ?>
                <tr>
                    <td><?php echo htmlspecialchars($record['attendance_date']); ?></td>
                    <td><?php echo htmlspecialchars($record['subject']); ?></td>
                    <td class="<?php echo strtolower($record['status']) === 'present' ? 'present' : 'absent'; ?>">
                        <?php echo htmlspecialchars($record['status']); ?>
                    </td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>
</div>

<!-- Styling -->
<style>
    body {
        font-family: Arial, sans-serif;
        background-color: #f4f4f4;
        margin: 0;
        padding: 0;
    }

    nav {
        background-color: navy;
        color: white;
        padding: 15px ;
    }

    nav ul {
        display: flex;
        justify-content: center;
        list-style: none;
        margin: 0;
        padding: 0;
    }

    nav ul li {
        margin: 0 15px;
    }

    nav ul li a {
        color: white;
        text-decoration: none;
        padding: 10px;
    }

    nav ul li a:hover {
        background-color: #007bff;
        border-radius: 5px;
    }

    .container {
        width: 80%;
        margin: 20px auto;
        background-color: white;
        padding: 20px;
        border-radius: 10px;
        box-shadow: 0 0 10px rgba(0, 0, 0, 0.1);
    }

    h1 {
        text-align: center;
        color: #333;
    }

    .attendance-table {
        width: 100%;
        border-collapse: collapse;
        margin-top: 20px;
    }

    .attendance-table th, .attendance-table td {
        padding: 12px;
        text-align: left;
        border: 1px solid #ddd;
    }

    .attendance-table th {
        background-color: #007bff;
        color: white;
    }

    .attendance-table td {
        background-color: #f9f9f9;
    }

    .attendance-table td.present {
        background-color: #e0f7e0;
        color: green;
    }

    .attendance-table td.absent {
        background-color: #ffcccc;
        color: red;
    }

    .attendance-table tr:hover {
        background-color: #f1f1f1;
    }
</style>

</body>
</html>

<?php
$conn->close();
?>
