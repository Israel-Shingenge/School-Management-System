<?php
session_start();
if (!isset($_SESSION['email'])) {
    header("Location: login.php");  
    exit;
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Dashboard</title>
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/dashboard.css">
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/login.css">
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/communication.css">

    
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.0.0-beta3/css/all.min.css">

    <script defer src="/SchoolManagementSystem/js scripts/script.js"></script>
        <script defer src="/SchoolManagementSystem/js scripts/script.js"></script>

</head>
<body>

    <nav>
        <ul>
            <li><a href="/SchoolManagementSystem/main/home.html">Home</a></li>
            <li><a href="/SchoolManagementSystem/main/dashboard.php">Dashboard</a></li>
            <li><a href="/SchoolManagementSystem/main/communication.html">Communication</a></li>
            <li><a href="/SchoolManagementSystem/main/examdashboard/examdashboard.html">Examination</a></li>
            <li><a href="/SchoolManagementSystem/main/teacherMan.html">Teacher</a></li>
            <li><a href="/SchoolManagementSystem/main/student.html">Student</a></li>
            <li><a href="/SchoolManagementSystem/main/fee.html">Fees</a></li>
            <li><a href="/SchoolManagementSystem/main/AboutUs.html">About us</a></li>
            <li><a href="/SchoolManagementSystem/backend/logout.php">Logout</a></li>
        </ul>
    </nav>
    <div class="dashboard-container">
        
    <section class="welcome-section">
    <h1>Welcome, <?php echo htmlspecialchars($_SESSION['first_name'] . ' ' . $_SESSION['last_name']); ?></h1>
    <p>Manage your courses, view upcoming events, and stay up-to-date with announcements.</p>
    </section>

        <div class="dashboard-panels">

            <div class="panel announcements">
                <h3><i class="fas fa-bullhorn"></i> Announcements</h3>
                <ul>
                    <li>Library hours extended during exam week!</li>
                    <li>New resources added to the Math department.</li>
                    <li>Sports day on November 25th.</li>
                </ul>

                <button  onclick="location.href='/SchoolManagementSystem/main/news.html'" class="view-more"><i class="fas fa-newspaper"></i> View More</button>
            </div>

            <div class="panel events">
                <h3><i class="fas fa-calendar-alt"></i> Upcoming Events</h3>
                <ul>
                    <li><strong>Nov 15</strong> - Cultural Festival</li>
                    <li><strong>Nov 20</strong> - Science Fair</li>
                    <li><strong>Dec 1</strong> - Parent-Teacher Conference</li>
                </ul>
                <button  onclick="location.href='/SchoolManagementSystem/main/calendar.html'" class="view-more"><i class="fas fa-calendar"></i> View full Calendar</button>
            </div>

            <div class="panel performance" id="manage-courses-panel">
                <h3><i class="fas fa-book"></i> Manage Subjects</h3>
                <div class="courses-container">
                    <div class="available-subjects">
                        <h4>Search and Enroll in Subjects</h4>
                        <div class="search-container">
                            <input type="text" id="subject-search" placeholder="Enter subject name">
                            <button onclick="searchAndEnrollSubject()">Enroll</button>
                        </div>
                        <p id="search-result"></p>
                    </div>
                    <div class="enrolled-subjects">
                        <h4>Your Enrolled Subjects</h4>
                        <ul id="enrolled-subjects"></ul>
                    </div>
                </div>
            </div>

            <div class="panel tasks">
                <h3><i class="fas fa-tasks"></i> Tasks & Reminders</h3>
                <ul id="task-list"></ul>
                <input type="text" id="new-task" placeholder="Enter new task" />
                <button class="add-task" onclick="addTask()"><i class="fas fa-plus-circle"></i> Add Task</button>
            </div>
            
        </div>
    </div>

    <script>
        function removeTask(button) {
    const taskItem = button.parentElement; 
    taskItem.remove(); 
}

function searchAndEnrollSubject() {
    const searchInput = document.getElementById('subject-search');
    const searchResult = document.getElementById('search-result');
    const enrolledSubjects = document.getElementById('enrolled-subjects');

    const searchTerm = searchInput.value.trim().replace(/\w\S*/g, 
        txt => txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase());

    searchResult.textContent = '';

    const availableSubjects = [
        'Mathematics', 'Science', 'History', 'English', 'Biology', 
        'Chemistry', 'Physics', 'Computer Science', 'Geography', 'Literature','German','Business Studies','Accounting'
    ];

    if (availableSubjects.includes(searchTerm)) {
        const existingEnrollments = Array.from(enrolledSubjects.children)
            .map(li => li.textContent.replace('Deregister', '').trim());

        if (existingEnrollments.includes(searchTerm)) {
            searchResult.textContent = `You are already enrolled in ${searchTerm}.`;
            searchResult.style.color = 'orange';
        } else {
            const li = document.createElement('li');
            li.innerHTML = `${searchTerm} <button onclick="deregisterCourse(this)">Deregister</button>`;
            enrolledSubjects.appendChild(li);
            
            searchResult.textContent = `Successfully enrolled in ${searchTerm}!`;
            searchResult.style.color = 'black';
        }
    } else {
        searchResult.textContent = `Sorry, ${searchTerm} is not available.`;
        searchResult.style.color = 'black';
    }

    searchInput.value = '';
}

function deregisterCourse(button) {
    const subjectItem = button.parentElement;
    const courseName = subjectItem.textContent.replace('Deregister', '').trim();
    
    subjectItem.remove();
    
    const searchResult = document.getElementById('search-result');
    searchResult.textContent = `${courseName} has been unenrolled.`;
    searchResult.style.color = 'blue';
}


function addTask() {
    const taskInput = document.getElementById('new-task');
    const taskList = document.getElementById('task-list');
    const taskValue = taskInput.value.trim();

    if (taskValue) {
        const li = document.createElement('li');
        li.innerHTML = `<input type="checkbox"> ${taskValue} <button onclick="removeTask(this)">Remove</button>`;
        taskList.appendChild(li);
        taskInput.value = ''; 
    } else {
        alert('Please enter a task.'); 
    }
}
    </script>

    <script src="https://cdn.jsdelivr.net/npm/chart.js"></script>
    <script src="/SchoolManagementSystem/js scripts/script.js" defer></script>

</body>
</html>
