

document.addEventListener("DOMContentLoaded", function () {
    const roleInputs = document.querySelectorAll("input[name='role']");
    const studentFields = document.getElementById('studentFields');
    const gradeField = document.querySelector("input[name='grade']");
    const parentNameField = document.querySelector("input[name='parent_name']");
    const parentContactField = document.querySelector("input[name='parent_contact']");

    function toggleStudentFields() {
        const selectedRole = Array.from(roleInputs).find(input => input.checked)?.value;
        if (selectedRole === 'student') {
            studentFields.style.display = 'block';
            gradeField.setAttribute('required', 'true');
            parentNameField.setAttribute('required', 'true');
            parentContactField.setAttribute('required', 'true');
        } else {
            studentFields.style.display = 'none';
            gradeField.removeAttribute('required');
            parentNameField.removeAttribute('required');
            parentContactField.removeAttribute('required');
        }
    }

    roleInputs.forEach(input => {
        input.addEventListener('change', toggleStudentFields);
    });

    toggleStudentFields();

    const passwordToggles = document.querySelectorAll('.password-toggle');
    passwordToggles.forEach(toggle => {
        toggle.addEventListener('click', function () {
            const input = toggle.previousElementSibling;
            if (input.type === "password") {
                input.type = "text";
                toggle.innerHTML = '<i class="fas fa-eye-slash"></i>';
            } else {
                input.type = "password";
                toggle.innerHTML = '<i class="fas fa-eye"></i>';
            }
        });
    });

    // Only attach event listener to signUpForm if it exists
    const signUpForm = document.getElementById("signUpForm");
    if (signUpForm) {  
        signUpForm.addEventListener("submit", function (event) {
            const password = signUpForm.querySelector("input[name='password']").value;
            const repeatPassword = signUpForm.querySelector("input[name='repeat_password']").value;

            if (password !== repeatPassword) {
                alert("Passwords do not match.");
                event.preventDefault();
            }
        });
    }

    // Sign in form validation (same check)
    const signInForm = document.getElementById("signInForm");
    if (signInForm) {  // Check if signInForm exists
        signInForm.addEventListener("submit", function (event) {
            const username = signInForm.querySelector("input[name='email']").value;
            const password = signInForm.querySelector("input[name='password']").value;

            if (!username || !password) {
                alert("Please fill in all fields.");
                event.preventDefault();
            }
        });
    }

document.querySelector('form').onsubmit = function(event) {
    event.preventDefault(); 
    confirmPayment(); 
    this.submit(); 
};

function openLessonPlans() {
    window.open('https://drive.google.com/drive/u/0/folders/YOUR_FOLDER_ID', '_blank');
}

function openAttendanceTracker() {
    window.open('https://docs.google.com/spreadsheets/d/YOUR_SHEET_ID', '_blank');
}

function openAssignments() {
    window.open('https://classroom.google.com/', '_blank');
}

function openClassSchedule() {
    window.open('https://calendar.google.com/calendar/u/0/r', '_blank');
}

function openPerformanceEvaluation() {
    window.open('https://forms.gle/Tmx5a79G3RJ4mXYq5', '_blank');
}

function contactStudents() {
    window.open('mailto:?bcc=student1@example.com,student2@example.com', '_self');
}

function openExamScheduleCalendar() {
    window.open('https://calendar.google.com/', '_blank');
}

function goToFeesPage() {
    window.location.href = "/SchoolManagementSystem/main/fee.html";
}

function openMeetingCalendar() {
    window.open('https://timetreeapp.com/', '_blank');
}

const lessonPlansButton = document.getElementById("lessonPlansButton");
if (lessonPlansButton) {
    lessonPlansButton.addEventListener("click", openLessonPlans);
}

const attendanceTrackerButton = document.getElementById("attendanceTrackerButton");
if (attendanceTrackerButton) {
    attendanceTrackerButton.addEventListener("click", openAttendanceTracker);
}

const assignmentsButton = document.getElementById("assignmentsButton");
if (assignmentsButton) {
    assignmentsButton.addEventListener("click", openAssignments);
}

const classScheduleButton = document.getElementById("classScheduleButton");
if (classScheduleButton) {
    classScheduleButton.addEventListener("click", openClassSchedule);
}

const performanceEvaluationButton = document.getElementById("performanceEvaluationButton");
if (performanceEvaluationButton) {
    performanceEvaluationButton.addEventListener("click", openPerformanceEvaluation);
}

const contactStudentsButton = document.getElementById("contactStudentsButton");
if (contactStudentsButton) {
    contactStudentsButton.addEventListener("click", contactStudents);
}

const examScheduleButton = document.getElementById("examScheduleButton");
if (examScheduleButton) {
    examScheduleButton.addEventListener("click", openExamScheduleCalendar);
}

const feesPageButton = document.getElementById("feesPageButton");
if (feesPageButton) {
    feesPageButton.addEventListener("click", goToFeesPage);
}

const meetingCalendarButton = document.getElementById("meetingCalendarButton");
if (meetingCalendarButton) {
    meetingCalendarButton.addEventListener("click", openMeetingCalendar);
}

console.log("JavaScript file loaded successfully");
}); 