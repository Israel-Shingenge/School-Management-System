document.addEventListener("DOMContentLoaded", function() {
    fetchGrades();
    fetchStudents();
});

function fetchGrades() {
    const studentId = 1; 
    fetch(`/SchoolManagementSystem/backend/gradeManagement.php?action=fetch_grades&student_id=${studentId}`)
        .then(response => response.json())
        .then(data => {
            console.log("Grades:", data);
        })
        .catch(error => console.error('Error fetching grades:', error));
}

function fetchStudents() {
    fetch(`/SchoolManagementSystem/backend/studentManagement.php?action=fetch_students`)
        .then(response => response.json())
        .then(data => {
            console.log("Students:", data);
          
        })
        .catch(error => console.error('Error fetching students:', error));
}