
        const calendar = document.querySelector('.calendar');
        const monthYear = document.getElementById('month-year');
        const overlay = document.querySelector('.overlay');
        const addEventForm = document.querySelector('.add-event-form');
        const addEventBtn = document.getElementById('add-event-btn');
        const saveEventBtn = document.getElementById('save-event-btn');
        const closeBtns = document.querySelectorAll('.close-btn');
        const eventDateInput = document.getElementById('event-date');
        const eventTitleInput = document.getElementById('event-title');
        const formTitle = document.getElementById('form-title');

        let events = [
            { id: 1, date: '2024-11-05', title: 'Math Workshop' },
            { id: 2, date: '2024-11-07', title: 'Science Fair' },
            { id: 3, date: '2024-11-10', title: 'Parent-Teacher Meeting' },
            { id: 4, date: '2024-11-20', title: 'Field Trip' },
        ];

        let editEventId = null;

        function generateCalendar(year, month) {
            const firstDay = new Date(year, month, 1).getDay();
            const daysInMonth = new Date(year, month + 1, 0).getDate();

            calendar.innerHTML = '';

            // Fill in blanks before the first day
            for (let i = 0; i < firstDay; i++) {
                calendar.innerHTML += '<div class="day"></div>';
            }

            // Fill in the days of the month
            for (let day = 1; day <= daysInMonth; day++) {
                const date = `${year}-${String(month + 1).padStart(2, '0')}-${String(day).padStart(2, '0')}`;
                const dayEvents = events.filter(event => event.date === date);
                let eventHTML = '';
                dayEvents.forEach(event => {
                    eventHTML += `
                        <div class="event">
                            <span>${event.title}</span>
                            <button onclick="editEvent(${event.id})">✎</button>
                            <button onclick="deleteEvent(${event.id})">🗑</button>
                        </div>
                    `;
                });

                calendar.innerHTML += `
                    <div class="day">
                        <div class="date">${day}</div>
                        ${eventHTML}
                    </div>
                `;
            }
        }

        function showAddEventForm(edit = false) {
            overlay.style.display = 'block';
            addEventForm.style.display = 'block';
            formTitle.textContent = edit ? 'Edit Event' : 'Add Event';
        }

        function closeAddEventForm() {
            overlay.style.display = 'none';
            addEventForm.style.display = 'none';
            eventDateInput.value = '';
            eventTitleInput.value = '';
            editEventId = null;
        }

        function saveEvent() {
            const eventDate = eventDateInput.value;
            const eventTitle = eventTitleInput.value;

            if (eventDate && eventTitle) {
                if (editEventId) {
                    // Edit existing event
                    const event = events.find(e => e.id === editEventId);
                    event.date = eventDate;
                    event.title = eventTitle;
                } else {
                    // Add new event
                    const newEvent = {
                        id: Date.now(),
                        date: eventDate,
                        title: eventTitle
                    };
                    events.push(newEvent);
                }

                const [year, month] = eventDate.split('-');
                generateCalendar(parseInt(year), parseInt(month) - 1);
                closeAddEventForm();
            }
        }

        function editEvent(id) {
            const event = events.find(e => e.id === id);
            if (event) {
                eventDateInput.value = event.date;
                eventTitleInput.value = event.title;
                editEventId = id;
                showAddEventForm(true);
            }
        }

        function deleteEvent(id) {
            events = events.filter(e => e.id !== id);
            const now = new Date();
            generateCalendar(now.getFullYear(), now.getMonth());
        }

        // Initialize calendar
        const now = new Date();
        generateCalendar(now.getFullYear(), now.getMonth());
        monthYear.textContent = now.toLocaleString('default', { month: 'long', year: 'numeric' });

        addEventBtn.addEventListener('click', () => showAddEventForm(false));
        closeBtns.forEach(btn => btn.addEventListener('click', closeAddEventForm));
        saveEventBtn.addEventListener('click', saveEvent);
