<?php

ini_set('display_errors', 1);
error_reporting(E_ALL);

session_start();

if (!isset($_SESSION['email'])) {
    die("Session not set. Please log in.");
}

$email = $_SESSION['email'];  

$host = 'localhost'; 
$dbname = 'management'; 
$username = 'root'; 
$password = ''; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "record_payment") {
    // Debugging: check POST data
    var_dump($_POST);

    $amount = htmlspecialchars(trim($_POST["amount"]));
    $paymentDate = htmlspecialchars(trim($_POST["payment_date"]));
    $paymentMethod = htmlspecialchars(trim($_POST["payment_method"]));

    $stmt = $conn->prepare("INSERT INTO payments (email, amount, payment_date, payment_method) VALUES (?, ?, ?, ?)");
    
    if ($stmt === false) {
        die("Error preparing statement: " . $conn->error);
    }

    $stmt->bind_param("sdss", $email, $amount, $paymentDate, $paymentMethod);

    if ($stmt->execute()) {
    
        echo "Payment recorded successfully!";
        header("Location: /SchoolManagementSystem/main/fee.html");
        exit;
    } else {
        echo "Error executing query: " . $stmt->error;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == "fetch_payments") {
    $stmt = $conn->prepare("SELECT * FROM payments WHERE email = ?");
    $stmt->bind_param("s", $email);
    $stmt->execute();
    $result = $stmt->get_result();
    $payments = [];
    
    while ($row = $result->fetch_assoc()) {
        $payments[] = $row;
    }

    echo json_encode($payments);
}

$conn->close();
?>
