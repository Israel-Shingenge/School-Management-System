<?php
session_start();

if (!isset($_SESSION['email'])) {
    header("Location: login.php");  
    exit;
}

$email = $_SESSION['email'];  

$servername = "localhost";
$username = "root";
$password = "";
$dbname = "management"; 

$conn = new mysqli($servername, $username, $password, $dbname);
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$sql = "SELECT first_name, last_name,email, phone,role FROM users WHERE email = ?";
$stmt = $conn->prepare($sql);
$stmt->bind_param("s", $email);  
$stmt->execute();
$result = $stmt->get_result();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>View Profile</title>
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/profile.css">
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/home.css">
</head>
<body>
    <hr>
    <nav>
        <ul>
            <li><a href="/SchoolManagementSystem/index.html">Home</a></li>
            <li><a href="/SchoolManagementSystem/main/dashboard.html">Dashboard</a></li>
            <li><a href="/SchoolManagementSystem/main/communication.html">Communication</a></li>
            <li><a href="/SchoolManagementSystem/main/examdashboard/examdashboard.html">Examination</a></li>
            <li><a href="/SchoolManagementSystem/main/teacherMan.html">Teacher</a></li>
            <li><a href="/SchoolManagementSystem/main/student.html">Student</a></li>
            <li><a href="/SchoolManagementSystem/main/fee.html">Fees</a></li>
            <li><a href="/SchoolManagementSystem/main/AboutUs.html">About us</a></li>
        </ul>
    </nav>
    <hr>

    <div class="container">
        <h2>Student Profile</h2>
        <div id="student-details" class="student-details">
            <?php
            if ($result->num_rows > 0) {
                $user = $result->fetch_assoc();
                echo "<table>";
                echo "<tr><th>First Name</th><td>" . htmlspecialchars($user['first_name']) . "</td></tr>";
                echo "<tr><th>Last Name</th><td>" . htmlspecialchars($user['last_name']) . "</td></tr>";
                echo "<tr><th>Email</th><td>" . htmlspecialchars($user['email']) . "</td></tr>";
                echo "<tr><th>Phone</th><td>" . htmlspecialchars($user['phone']) . "</td></tr>";
                echo "<tr><th>Role</th><td>" . htmlspecialchars($user['role']) . "</td></tr>";
                echo "</table>";
            } else {
                echo "<p>No user found with that email.</p>";
            }
            ?>
        </div>
    </div>

</body>
</html>

<?php
$stmt->close();
$conn->close();
?>
