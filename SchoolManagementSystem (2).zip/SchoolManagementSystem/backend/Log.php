<?php

session_start();

$host = "localhost";
$username = "root"; 
$password = ""; 
$dbname = "management"; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

// Handle login
if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_type'] == 'signin') {
    $email = $_POST['email'];
    $password = $_POST['password'];
    $role = $_POST['role'];

    $sql = "SELECT * FROM users WHERE email = ? AND role = ?";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ss", $email, $role);
    $stmt->execute();
    $result = $stmt->get_result();

    if ($result->num_rows > 0) {
        $user = $result->fetch_assoc();
        if (password_verify($password, $user['password'])) {
            $_SESSION['user_id'] = $user['id'];
            $_SESSION['role'] = $role;
            $_SESSION['email'] = $user['email'];
            $_SESSION['first_name'] = $user['first_name'];  // Store first name
            $_SESSION['last_name'] = $user['last_name'];    // Store last name
    
            header("Location: /SchoolManagementSystem/main/home.html");
            exit;
        } else {
            echo "Invalid password.";
        }
    } else {
        echo "User  not found.";
    }
}

if ($_SERVER['REQUEST_METHOD'] == 'POST' && $_POST['form_type'] == 'signup') {
    $first_name = $_POST['first_name'];
    $last_name = $_POST['last_name'];
    $email = $_POST['email'];
    $phone = $_POST['phone'];
    $role = $_POST['role'];
    $password = password_hash($_POST['password'], PASSWORD_DEFAULT);

    // Specific fields for student role
    if ($role == 'student') {
        $grade = $_POST['grade'];
        $parent_name = $_POST['parent_name'];
        $parent_contact = $_POST['parent_contact'];
    }

    // Insert user into the database
    $sql = "INSERT INTO users (first_name, last_name, email, phone, role, password) VALUES (?, ?, ?, ?, ?, ?)";
    $stmt = $conn->prepare($sql);
    $stmt->bind_param("ssssss", $first_name, $last_name, $email, $phone, $role, $password);
    if ($stmt->execute()) {
        // Successful signup
        echo "User registered successfully.";

        $_SESSION['user_id'] = $stmt->insert_id;  
        $_SESSION['role'] = $role;
        $_SESSION['email'] = $email;  

        header("Location: /SchoolManagementSystem/index.html");
        exit;
    } else {
        echo "Error: " . $stmt->error;
    }
}

?>
