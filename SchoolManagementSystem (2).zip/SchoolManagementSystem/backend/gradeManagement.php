<?php
$host = 'localhost';
$dbname = 'management';
$username = 'root';
$password = '';

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['examSelect'])) {
    // Get the email manually from the POST data
    $email = htmlspecialchars(trim($_POST['email'])); // Get the email from form input
    $examSelect = htmlspecialchars(trim($_POST['examSelect']));
    $subjects = $_POST['subject'];
    $grades = $_POST['grade'];
    $remarks = $_POST['remarks'];

    // Check if the email is valid (can be adjusted based on your validation rules)
    if (empty($email)) {
        die("Error: Email cannot be empty.");
    }

    foreach ($subjects as $index => $subject) {
        $grade = $grades[$index];
        $remark = $remarks[$index];

        $stmt = $conn->prepare("INSERT INTO grades (email, subject, grade, remarks, exam_name) VALUES (?, ?, ?, ?, ?)");

        if ($stmt === false) {
            die("Error preparing statement: " . $conn->error);
        }

        // Bind the parameters (email, subject, grade, remark, exam name)
        $stmt->bind_param("sssss", $email, $subject, $grade, $remark, $examSelect);

        if (!$stmt->execute()) {
            echo "Error inserting grade for subject $subject: " . $stmt->error;
        }
    }
    echo "Grades inputted successfully!";
    header("Location: /SchoolManagementSystem/main/examdashboard/grades.html");
        exit;
}

$conn->close();
?>
