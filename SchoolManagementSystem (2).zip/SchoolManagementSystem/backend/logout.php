<?php
session_start();

echo "Session data before logout: ";
print_r($_SESSION);

if (isset($_SESSION['email'])) {
    echo "User email: " . $_SESSION['email'];
} else {
    echo "No user logged in.";
}

session_unset();
session_destroy();

echo "Session data after logout: ";
print_r($_SESSION);

header("Location: /SchoolManagementSystem/index.html");
exit;
?>
