<?php
session_start();
$host = 'localhost'; 
$dbname = 'management'; 
$username = 'root'; 
$password = ''; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "record_attendance") {
    $attendanceDate = htmlspecialchars(trim($_POST["attendance_date"]));
    $subject = htmlspecialchars(trim($_POST["subject"]));
    $students = $_POST['students']; 

    foreach ($students as $student) {
        $studentName = htmlspecialchars(trim($student['name']));
        $email = htmlspecialchars(trim($student['email'])); 
        $status = htmlspecialchars(trim($student['status']));
        
        $stmt = $conn->prepare("INSERT INTO attendance (student_name, email, attendance_date, subject, status) VALUES (?, ?, ?, ?, ?)");
        $stmt->bind_param("sssss", $studentName, $email, $attendanceDate, $subject, $status);
        
        if (!$stmt->execute()) {
            echo "Error: " . $stmt->error;
        }
    }

    echo "Attendance recorded successfully!";

    header("Location: /SchoolManagementSystem/main/attendance.html");
            exit;
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == "fetch_attendance") {
    $result = $conn->query("SELECT * FROM attendance");
    $attendance = [];
    while ($row = $result->fetch_assoc()) {
        $attendance[] = $row;
    }
    echo json_encode($attendance);
}

$conn->close();
?>
