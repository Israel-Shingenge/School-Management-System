<?php
session_start();

if (!isset($_SESSION['email'])) {
    echo "You must be logged in to view grades.";
    exit;
}

$email = $_SESSION['email']; 

$host = 'localhost';
$dbname = 'management';
$username = 'root';
$password = '';
$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

$stmt = $conn->prepare("SELECT subject, grade, remarks, exam_name, created_at FROM grades WHERE email = ?");
$stmt->bind_param("s", $email);

if ($stmt->execute()) {
    $result = $stmt->get_result();
    if ($result->num_rows > 0) {
       
        echo "<table class='grades-table'>";
        echo "<thead><tr><th>Subject</th><th>Grade</th><th>Remarks</th><th>Exam</th><th>Date</th></tr></thead>";
        echo "<tbody>";
        while ($row = $result->fetch_assoc()) {
            echo "<tr>";
            echo "<td>{$row['subject']}</td>";
            echo "<td>{$row['grade']}</td>";
            echo "<td>{$row['remarks']}</td>";
            echo "<td>{$row['exam_name']}</td>";
            echo "<td>{$row['created_at']}</td>";
            echo "</tr>";
        }
        echo "</tbody>";
        echo "</table>";
    } else {
        echo "<p>No grades found for this email.</p>";
    }
} else {
    echo "Error retrieving grades: " . $conn->error;
}

$stmt->close();
$conn->close();
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Grades for Student</title>
    <link rel="stylesheet" href="/SchoolManagementSystem/styling/communication.css">
    <style>
        body {
            font-family: Arial, sans-serif;
            margin: 40px;
            background-color: #fff;
        }
        h2 {
            text-align: center;
            color: #333;
        }
        .grades-table {
            width: 100%;
            margin: 20px 0;
            border-collapse: collapse;
            box-shadow: 0 4px 8px rgba(0, 0, 0, 0.1);
            background-color: aliceblue;
        }
        .grades-table thead {
            background-color: #007bff;
            color: white;
        }
        .grades-table th, .grades-table td {
            padding: 12px;
            text-align: left;
        }
        .grades-table tbody tr:nth-child(even) {
            background-color: #f2f2f2;
        }
        .grades-table tbody tr:hover {
            background-color: #ddd;
        }
        .grades-table th {
            font-weight: bold;
            border: 1px solid grey;
        }

        .grades-table td{
            border: 1px solid grey;
        }
    </style>
</head>
<body>

    <nav>
        <ul>
            <li><a href="/SchoolManagementSystem/index.html">Home</a></li>
            <li><a href="/SchoolManagementSystem/main/dashboard.html">Dashboard</a></li>
            <li><a href="/SchoolManagementSystem/main/communication.html">Communication</a></li>
            <li><a href="/SchoolManagementSystem/main/examdashboard/examdashboard.html">Examination</a></li>
            <li><a href="/SchoolManagementSystem/main/teacherMan.html">Teacher</a></li>
            <li><a href="/SchoolManagementSystem/main/student.html">Student</a></li>
            <li><a href="/SchoolManagementSystem/main/fee.html">Fees</a></li>
            <li><a href="/SchoolManagementSystem/main/AboutUs.html">About us</a></li>
            <li><a href="/SchoolManagementSystem/backend/logout.php">Logout</a></li>
        </ul>
    </nav>

</body>
</html>
