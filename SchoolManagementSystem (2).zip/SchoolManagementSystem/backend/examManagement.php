<?php
session_start();
$host = 'localhost'; 
$dbname = 'management'; 
$username = 'root'; 
$password = ''; 

$conn = new mysqli($host, $username, $password, $dbname);

if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

if ($_SERVER["REQUEST_METHOD"] == "POST" && isset($_POST['action']) && $_POST['action'] == "schedule_exam") {
    $examType = htmlspecialchars(trim($_POST["exam_type"]));
    $subject = htmlspecialchars(trim($_POST["subject"]));
    $examDate = htmlspecialchars(trim($_POST["exam_date"]));
    $startTime = htmlspecialchars(trim($_POST["start_time"]));
    $duration = htmlspecialchars(trim($_POST["duration"]));

    $stmt = $conn->prepare("INSERT INTO exams (exam_type, subject, exam_date, start_time, duration) VALUES (?, ?, ?, ?, ?)");
    $stmt->bind_param("ssssi", $examType, $subject, $examDate, $startTime, $duration);
    
    if ($stmt->execute()) {
        echo "Exam scheduled successfully!";

        header("Location: /SchoolManagementSystem/main/examdashboard/examschedule.html");
    exit;
    } else {
        echo "Error: " . $stmt->error;
    }
}

if ($_SERVER["REQUEST_METHOD"] == "GET" && isset($_GET['action']) && $_GET['action'] == "fetch_exams") {
    $result = $conn->query("SELECT * FROM exams");
    $exams = [];
    while ($row = $result->fetch_assoc()) {
        $exams[] = $row;
    }
    echo json_encode($exams);
}

$conn->close();
?> 
